module.exports = {
    url:"mongodb+srv://Wenjie:9PTHwjIBBu53vfkj@cluster0.sdm6icg.mongodb.net/SportStore?retryWrites=true&w=majority"
};