module.exports = {

    url: "mongodb+srv://seanwang619:vljp8sH2KFy6AQ51@cluster0.kudk2bv.mongodb.net/SportStore?retryWrites=true&w=majority"

};