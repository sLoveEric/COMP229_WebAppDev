module.exports = {

    url: "mongodb+srv://seanwang619:vljp8sH2KFy6AQ51@cluster0.kudk2bv.mongodb.net/DressStore?retryWrites=true&w=majority"

};