module.exports = function() {
    const message = 'Hello';
    console.log(message);
 }
 
